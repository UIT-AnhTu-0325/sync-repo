﻿namespace assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a word: ");
            int input = int.Parse(Console.ReadLine());
            
        }
    }
}